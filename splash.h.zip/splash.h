#define splash1_width  82
#define splash1_height 64

const uint8_t PROGMEM splash1_data[] = {
//senza il logo adafruit

};

#define splash2_width  115
#define splash2_height  32

const uint8_t PROGMEM splash2_data[] = {
//senza il logo adafruit (ver più piccola) 

};
